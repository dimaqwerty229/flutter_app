## 0.0.11

- Disabe do_not_use_environment as we need to for Flutter for web

## 0.0.10

- Update `dart_code_metrics` dependency to 4.10.1
- Ignore `mockito` mocks generated to be alongside source test files

## 0.0.9

- Remove `diagnostic_describe_all_properties` rule
- Disable cyclomatic complexity metric for tests

## 0.0.8

- Exclude generated files

## 0.0.7

- Add more useful DCM rules.

## 0.0.6

- Add a separate anayisis options file for tests

## 0.0.5

- Remove the `sort_constructors_first` rule

## 0.0.4

- Set maximum method length to 200
- Set maximum parameters list length to 7

## 0.0.3

- Configure rules based on Flutter 2.5 (Dart 2.14.4)

## 0.0.2

- Updated readme

## 0.0.1

- Preview
