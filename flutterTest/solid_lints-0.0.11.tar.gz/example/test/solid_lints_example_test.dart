import 'package:solid_lints_example/solid_lints_example.dart';
import 'package:test/test.dart';

class Service {
  int method() {
    return 0;
  }
}

class ServiceStub implements Service {
  @override
  int method() {
    return 1;
  }
}

void main() {
  //It's handy to use `late` in such situations.
  late Service service;
  setUp(() {
    service = ServiceStub();
  });

  //intentionally long test method to test for long-method rule
  const two = 2;
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
  test("addition", () {
    expect(sum(1, service.method()), equals(two));
  });
}
